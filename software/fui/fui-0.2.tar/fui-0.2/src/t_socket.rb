#!/usr/bin/env ruby
# 
# 2010      Nico Schottelius (nico-fui at schottelius.org)
# 
# This file is part of fui.
#
# fui is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# fui is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with fui. If not, see <http://www.gnu.org/licenses/>.
#
# Test fui's socket implementation.
#

require 'test/unit'
require 'socket.rb'
require 'mock_socket.rb'

class TestFuiSocket < Test::Unit::TestCase

   def setup
      @socketpath = "/tmp/fuitestsocket"
      @testmsg = "Test"
      @socketmock = MockFuiSocket.new(@socketpath)
      @socketfui = FuiSocket.new(@socketpath)
   end

   def teardown
      File::unlink(@socketpath)
   end

   def test_fui_socket
      @socketfui.send(@testmsg)
      readmsg = @socketmock.recv(@testmsg.length)

      assert (readmsg == @testmsg)
      puts "Successfully received: " + readmsg
   end

end

