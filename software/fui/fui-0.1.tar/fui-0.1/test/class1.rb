class Mc
   def initialize(name = "foobar")
      @name = name
   end

   def say_hi
      puts "Hello, @{name}!"
   end
end
