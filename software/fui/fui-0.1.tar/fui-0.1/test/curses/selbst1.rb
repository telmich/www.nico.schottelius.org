require "ncurses"

# First command in every ncurses app
Ncurses.initscr

# get keys like FX, cursors, etc.
Ncurses.keypad(Ncurses.stdscr, TRUE)

Ncurses.raw
Ncurses.noecho
Ncurses.printw("Type any character to see it in bold\n");
ch = Ncurses.getch
if ch == Ncurses::KEY_F1
   Ncurses.printw("F1 Key pressed")
else
   Ncurses.printw("The pressed key is ");
   Ncurses.attron(Ncurses::A_BOLD);
   Ncurses.printw("%c", ch);
   Ncurses.attroff(Ncurses::A_BOLD);
end

Ncurses.refresh

for i in 4..10
   Ncurses.mvaddstr(i, 19, "Hello, world!");
   sleep(0.5)
   Ncurses.refresh
end


sleep(2.5)

# Disable curse
Ncurses.endwin
