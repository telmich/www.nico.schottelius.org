puts 'Name?'
name = gets.chomp
puts 'Du bist ' + name
