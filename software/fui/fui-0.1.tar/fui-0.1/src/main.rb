# Probably rename this later ;-)

# cleanup ncurses at the end
def endfui
   Ncurses.endwin
end


# Intro: Contains init of ncurses

intro="Welcome to fui, the fancy user interface"

require "ncurses"
Ncurses.initscr
Ncurses.keypad(Ncurses.stdscr, TRUE)
Ncurses.attron(Ncurses::A_BOLD);

x = (Ncurses.COLS/2)-intro.length/2
y = Ncurses.LINES/2

Ncurses.move(y, x)
Ncurses.printw("Welcome to fui, the fancy user interface\n")

Ncurses.attroff(Ncurses::A_BOLD);
Ncurses.border(*([0]*8))
Ncurses.refresh
Ncurses.noecho
Ncurses.raw
ch = Ncurses.getch
#Ncurses.stdscr.clear

# height input
hinput = 3

# height messages
hmsg = Ncurses.LINES-hinput

# WINDOW.new: height, width, x-offset, y-offset
wmsg     = Ncurses::WINDOW.new(hmsg, 0, 0, 0)
winput   = Ncurses::WINDOW.new(hinput, 0, hmsg, 0)

# add borders
wmsg.border(*([0]*8))
#winput.border(*([0]*8))
wmsg.noutrefresh()
winput.move(1, 1)
winput.addstr("> ")
Ncurses.echo
winput.noutrefresh()
Ncurses.doupdate() # update read screen

# read input and write it to the wmsg window
begin
   input = ""
   winput.wgetstr input

   wmsg.move(1, 2)
   wmsg.addstr "<user> " + input
   winput.clear
   winput.move(1, 1)
   winput.addstr("> ")
   wmsg.noutrefresh
   winput.noutrefresh
   Ncurses.doupdate
end while input != "/quit"

endfui
