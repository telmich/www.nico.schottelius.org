require "ncurses"

Ncurses.initscr

for i in 4..10
   Ncurses.mvaddstr(i, 19, "Hello, world!");
   Ncurses.refresh
end


sleep(2.5)

Ncurses.endwin
