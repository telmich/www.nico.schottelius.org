puts '15'.+ '15' + ' len: ' + 'teststring'.length.to_s
puts (15.-15).to_f

#puts '15'.reverse (15.to_s).reverse
