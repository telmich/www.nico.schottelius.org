a='text '
b=' aa'


puts a + b + a *5
