name1="abc"
puts 'Name?'
name = gets.chomp
puts 'Du bist ' + name

if name1 == name
   puts 'Du bist es!!!'
end
