#!ruby
# 
# 2010      Nico Schottelius (nico-fui at schottelius.org)
# 
# This file is part of fui.
#
# fui is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# fui is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with fui. If not, see <http://www.gnu.org/licenses/>.
#
# Implment the ncurses user interface
#

require "ncurses"
require "ui"

class FuiUINcurses < FuiUI

   def initialize(introtext = "Welcome to fui, the fancy user interface")
      @introtext = introtext

      # First function to be called by any ncurses application
      Ncurses.initscr

      # Enable function and cursor key interpretation
      Ncurses.keypad(Ncurses.stdscr, TRUE)

      refresh
   end

   def refresh
      @cols = Ncurses.COLS
      @lines = Ncurses.LINES
   end

   # Display intro screen
   def intro
      x, y = middletext(@introtext)

      Ncurses.move(x, y)
      boldprint(@introtext)
      Ncurses.border(*([0]*8))
      Ncurses.refresh
      Ncurses.noecho
      Ncurses.raw
      Ncurses.getch
   end

   def boldprint(text)
      bold
      Ncurses.printw(@introtext)
      boldoff
   end
   
   def bold
      Ncurses.attron(Ncurses::A_BOLD)
   end
   
   def boldoff
      Ncurses.attroff(Ncurses::A_BOLD)
   end
   
   # return x,y array
   def middletext(text)
      [ (@cols/2) - (text.length/2), @lines/2 ]
   end

   def teardown
      Ncurses.endwin
   end
end
