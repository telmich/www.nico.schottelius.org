/**A Java HTML Editor : Hted
	@Author Nico Schottelius
	@Version 1.0
	@Date 27-08-98
**/

/**This program contains to the eof.html package **/

/**Import useful packages: java.io.* for fileinput /output; java.awt.*
*for graphical;
*java.awt.event.* for mouse and keyboard actions
**/ 
import java.io.*;
import java.awt.*;
import java.awt.event.*;


public class Hted extends Frame implements ActionListener
{
    /**Declarate some Variables...**/
    TextArea iN;
    String nameOfFile = new String(" ");

    /**Static Strings, for language select**/
    
    static final String MENU		 	= new String("File");
    static final String MENU_NEW 		= new String("New");
    static final String MENU_OPEN  		= new String("Open");
    static final String MENU_SAVE  		= new String("Save");
    static final String MENU_PRINT 		= new String("Print");
    static final String MENU_SAVEAS		= new String("Save As");
    static final String MENU_QUIT	  	= new String("Quit");
    
    static final String MENU_TAG		= new String("Tags");
    static final String MENU_TAG_IMG		= new String("Image");
    static final String MENU_TAG_LINK		= new String("Link");
    static final String MENU_TAG_LINK_W		= new String("with target");
    static final String MENU_TAG_LINK_WO	= new String("without target");
    static final String MENU_TAG_SPEZI		= new String("Insert Spezification");
    static final String MENU_TAG_BODY		= new String("Insert body");
    static final String MENU_TAG_FRAME		= new String("Insert Frameset");
    static final String MENU_TAG_TABLE		= new String("Insert Table");
    static final String MENU_TAG_HR		= new String("Insert Vertical Line");
    static final String MENU_TAG_LINE		= new String("New Line");
    
    static final String MENU_TOOLS		= new String("Tools");
    static final String MENU_TOOLS_CUT		= new String("Cut");
    static final String MENU_TOOLS_PASTE	= new String("Paste");
    static final String MENU_TOOLS_COPY		= new String("Copy");
    
    static final String MENU_OPTIONS		= new String("Options");
    static final String MENU_OPTIONS_FONT	= new String("Set Font");
    
    static final String MENU_HELP		= new String("?");
    static final String MENU_HELP_HOWTO		= new String("Howto...?");
    static final String MENU_HELP_ABOUT		= new String("About");
    
    static final String OPEN_FILE	= new String("Open File");
    static final String SAVE_FILE	= new String("Save File");


    static final String DIALOG_TITLE	= new String("About");
    static final String BUTTON_OKAY	= new String("Okay!");

    
    static final String ERROR_READ	= new String("Read Error");
    static final String ERROR_WRITE	= new String("Write Error");

    /**The MenuItem Generator**/
    class MItem extends MenuItem 
    	{
	public MItem(String mIName, String mICom, ActionListener mILis)
		{
		super(mIName);
		setActionCommand(mICom);
		addActionListener(mILis);
		}
	public MItem(String mIName, String mICom, ActionListener mILis, int mIKey)
		{
		super (mIName, new MenuShortcut(mIKey));
                setActionCommand(mICom);
                addActionListener(mILis);
		}
	}					


    /**Class for focus getting and loosing but just for the textfield at startup
    *This will come some time Later: then a (c) is insert at startup, and at gaining Focus, clear with setText("");
    **/

    
    /**The Constructor**/
    
    public Hted(){ 
    /**Set the title**/
    super("Hted");
    
    /**set the size**/
    setSize(600,400);
    
    /**Listen to actions**/
    MyL main = new MyL();
    addWindowListener(main);
    
    /**The menues**/
    Menu mOpt = new Menu("Options");
    
    /**Items**/
    MenuItem neu, oeffnen, speichern, drucken, speichernals, beenden;
    
    neu = new MItem(MENU_NEW,"new",this,KeyEvent.VK_N);
    oeffnen = new MItem(MENU_OPEN,"open",this,KeyEvent.VK_O);
    speichern = new MItem(MENU_SAVE,"save",this,KeyEvent.VK_S);
    speichernals = new MItem(MENU_SAVEAS,"saveas",this,KeyEvent.VK_A);
    drucken = new MItem(MENU_PRINT,"print",this,KeyEvent.VK_P);
    beenden = new MItem(MENU_QUIT,"close",this,KeyEvent.VK_Q);

    /**Now add the Items**/
    /**First the file Menue**/
    Menu mFile = new Menu(MENU);
    mFile.add(neu);
    mFile.addSeparator();
    mFile.add(oeffnen);
    mFile.add(speichern);
    mFile.add(speichernals);
    mFile.addSeparator();
    mFile.add(beenden);

    /**Then the Tags**/
    Menu mTag = new Menu(MENU_TAG);
    Menu mTag_Link =new Menu(MENU_TAG_LINK);
    MenuItem line,img,with,withOut,spezi, body, frame;
    
    spezi = new MItem(MENU_TAG_SPEZI,"spezi",this);
    body = new MItem(MENU_TAG_BODY,"body",this);
    frame = new MItem(MENU_TAG_FRAME,"frame",this);
    with = new MItem(MENU_TAG_LINK_W,"with_target",this);
    withOut = new MItem(MENU_TAG_LINK_WO,"without_target",this);
    
    mTag_Link.add(withOut);
    mTag_Link.add(with);
    line = new MItem(MENU_TAG_LINE,"insert_line",this);
    img  = new MItem(MENU_TAG_IMG,"img",this);
    mTag.add(img);
    mTag.add(line);
    mTag.add(spezi);
    mTag.add(mTag_Link);

    /**Now the tools Menue**/
    Menu mTools =new Menu(MENU_TOOLS);
    MenuItem cut,paste,copy;
    cut		= new MItem(MENU_TOOLS_CUT,"cut",this);
    paste	= new MItem(MENU_TOOLS_PASTE,"paste",this);
    copy	= new MItem(MENU_TOOLS_COPY,"copy",this);
    mTools.add(cut);
    mTools.add(copy);
    mTools.add(paste);

    /**Now the Help Menue**/
    Menu mHelp = new Menu(MENU_HELP);
    MenuItem about, howto;
    about	= new MItem(MENU_HELP_ABOUT,"about",this,KeyEvent.VK_B);
    howto	= new MItem(MENU_HELP_HOWTO,"howto",this);
    mHelp.add(about);
    mHelp.add(howto);

    /**The options**/
    Menu mOptions	= new Menu(MENU_OPTIONS);
    MenuItem mIFont;
    mIFont		= new MItem(MENU_OPTIONS_FONT,"font",this);
    mOptions.add(mIFont);
	

    /**make a new Menubar**/
    MenuBar mB =new MenuBar();
    mB.add(mFile);
    mB.add(mTag);
    mB.add(mTools);
    mB.add(mOptions);
    mB.add(mHelp);
    mB.setHelpMenu(mHelp);
    setMenuBar(mB);


    
    /**New textfield for Input**/
    iN = new TextArea(" ",25,80,TextArea.SCROLLBARS_BOTH);
    iN.setFont(new Font("Arial",Font.PLAIN,15));
    iN.setText("");
    add(iN);
    iN.requestFocus();

    /**Other Components**/

    /**shows everthing**/
    show();

    }
    /**Listens if the close button is pressed; then exit**/
    
    private class MyL extends WindowAdapter{
    	public void windowClosing (WindowEvent event)
	{
	System.exit(0);
	}
	public void windowClosed(WindowEvent event){
	}
	public void windowOpened(WindowEvent event){}
	public void windowActivated(WindowEvent event){}
	public void windowDeactivated(WindowEvent event){
	}
	public void windowIconified(WindowEvent event){
	}
	public void windowDeiconified(WindowEvent event){}

    }

    /**Listens to INSIDE actions**/
    public void actionPerformed(ActionEvent y)
    {
    	String tpIn = new String("no command");
	tpIn = y.getActionCommand();
	if(tpIn == "close")
		System.exit(0);
	if(tpIn == "new"){
		iN.setText(" ");
		nameOfFile=null;
	}
	if (tpIn == "save" || tpIn == "saveas" || tpIn == "open"){
		filework(tpIn);
	}
	if
	(tpIn == "img" || tpIn == "link" || tpIn == "insert_line" || tpIn == "without_target" || tpIn == "spezi" || tpIn == "with_target"){
		tag(tpIn);
	}
	if(tpIn == "about" || tpIn == "howto"){
		help(tpIn);
	}

    }

    
    void tag(String tagName){
    	if (tagName == "insert_line"){
		String addTag = new String("<P>");
		int where = iN.getCaretPosition();
		iN.insert(addTag,where);
		iN.setCaretPosition(where+4);
		}
    	if (tagName == "img"){
    		String addTag = new String("<img src=\"\" width=\"\" height=\"\" alt=\"\">");
		int where = iN.getCaretPosition();
    		iN.insert(addTag,where);
		iN.setCaretPosition(where+10);
		}
    	if(tagName =="without_target"){
        	String addTag = new String("<A href=\"\">");
        	int where = iN.getCaretPosition();
        	iN.insert(addTag,where);
        	iN.setCaretPosition(where+9);
		}
    	if(tagName =="with_target"){
        	String addTag = new String("<A href=\"\" target=>");
        	int where = iN.getCaretPosition();
        	iN.insert(addTag,where);
        	iN.setCaretPosition(where+9);
    	}
    	if(tagName =="spezi"){
        	String addTag = new String("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\">\n"+
		"<html>\n<head>\n"+
		"<title>My HP</title>\n"+
		"<meta name=\"author\" content=\"urname\">\n"+
		"<META NAME=\"GENERATOR\" CONTENT=\"Hted (c) 98 by Nico Schottelius (nicos@pcsystems.de)\">\n"+
		"<link rel=stylesheet type=\"text/css\" href=\"page.css\">\n"+
		"</head>\n");
        	int where = 0;
        	iN.insert(addTag,where);
    	}
	
    }
    void help(String helpContent){
    }
    void filework(String Content){
    	/**Check if open was choosen**/
	if(Content =="open"){
		/**Open a LOAD File Dialog**/
		FileDialog fileOpen = new FileDialog (this,OPEN_FILE,FileDialog.LOAD);
		/**If no file was choosen before, set filter to *.html**/
		if (nameOfFile.equals(" "))
			fileOpen.setFile("*.html");
		/**If a file was choosen ,select it**/
		else
			fileOpen.setFile(nameOfFile);
		fileOpen.setSize(200,200);
		/**Show the dialog**/
		fileOpen.show();
		/**Set absolute PATH**/
		String nameFile = (fileOpen.getDirectory()+fileOpen.getFile());
		if (nameFile != null){
			nameOfFile = nameFile;
			try {
				File f = new File(nameFile);
				int laenge = (int) f.length();
				int haveRead = 0;
				FileInputStream im = new FileInputStream(f);
				byte[] data =new byte[laenge];
				while(haveRead < laenge)
					haveRead += im.read(data,haveRead,laenge - haveRead);
				im.close();
				iN.setText(new String(data));
			}
			catch (IOException dDD) 
			{
			iN.setText("Couldn�t open file: "+dDD);
			}
		}
         }
	 else{}
	 /**Check if a save Option is taken**/
	 if (Content == "saveas" || Content == "save")
	 	{
		/**Check if it is save and if a filename is taken**/
		if (Content == "save" && nameOfFile != null)
                {
		/**SAVE**/
			try {
                   		int laenge = iN.getText().length();
                       		File f = new File(nameOfFile);
                       		FileOutputStream out =new FileOutputStream(f);
                                byte []data =new byte [laenge];
                                data = iN.getText().getBytes();
                                out.write(data);
                                out.close();
                         }
                         catch (IOException fhla){
			 iN.setText("IOException "+fhla);
			 }
                }
             	/**If Option is not save, or nameOfFile is null, do a Save As*/
		else{
			/**Makes a new Filedialog with the title SAVE_FILE**/
			FileDialog fileOpen = new FileDialog (this,SAVE_FILE,FileDialog.SAVE);
			/**If no File is choosen, take *.html as a filter**/
			if (nameOfFile == null || nameOfFile ==" ")
				fileOpen.setFile("*.html");
			/**If a file is choosen**/
			else
				fileOpen.setFile(nameOfFile);
			/**shows the dialog**/
			fileOpen.show();
			/**Set the name as absolute**/
        	        String nameFile = (fileOpen.getDirectory()+fileOpen.getFile());
			/**Check if the filename is really not null**/
               		if (nameFile != null){
                        	nameOfFile = nameFile;
                        	try {
	                        	File f = new File(nameFile);
					FileOutputStream out =new FileOutputStream(f);
					int laenge = iN.getText().length();
					byte []data =new byte [laenge];
					data = iN.getText().getBytes();
					out.write(data);
					out.close();
					}
				catch (IOException fhla){
					iN.setText("Couldn�t save File: "+fhla);
				}
			}
		}
	}
    }
    /**the "main" Java program**/
    public static void main (String args[]){
    	new Hted();
    }
}
