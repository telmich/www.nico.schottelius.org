int gpm2_open_ps2(int fd);
int gpm2_decode_ps2(int fd);
