#!/bin/sh
# I am lazy -- Nico

autoheader && autoconf && ./configure && make
