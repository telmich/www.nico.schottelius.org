#!/bin/sh
# I am lazy -- Nico

./autogen.sh && ./configure && make
