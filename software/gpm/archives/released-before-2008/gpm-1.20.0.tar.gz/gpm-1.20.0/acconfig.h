/* Copyright (C) 1998 Ian Zimmerman <itz@transbay.net> */
/* Copyright (C) 2002 Nico Schottelius <nico@schottelius.org> */

@TOP@

/* GPM release number as a string. */
#define GPM_RELEASE ""

/* RMEV release number as a string. */
#define RMEV_RELEASE ""

/* PATHS */
#define SYSCONFDIR ""
#define SBINDIR    ""


/* define if the __u32 type exists either in sys/types.h or in linux/types.h */
#undef HAVE___U32
