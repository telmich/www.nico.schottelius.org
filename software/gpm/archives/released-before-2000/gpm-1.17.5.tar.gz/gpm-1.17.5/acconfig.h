/* Copyright (C) 1998 Ian Zimmerman <itz@transbay.net> */
/* $Id: acconfig.h,v 1.3 1998/12/31 06:04:53 itz Exp $ */

@TOP@

/* GPM release number as a string. */
#define GPM_RELEASE ""

/* RMEV release number as a string. */
#define RMEV_RELEASE ""

/* generic 32 bit type */
#undef __u32
