/* Copyright (C) 1998 Ian Zimmerman <itz@transbay.net> */
/* $Id: acconfig.h,v 1.4 1999/04/06 09:21:29 itz Exp $ */

@TOP@

/* GPM release number as a string. */
#define GPM_RELEASE ""

/* RMEV release number as a string. */
#define RMEV_RELEASE ""

/* define if the __u32 type exists either in sys/types.h or in
   linux/types.h */
#undef HAVE___U32
