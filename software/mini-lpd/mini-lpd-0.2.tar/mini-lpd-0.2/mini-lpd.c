/* mini-lpd (See RFC1179)
 * written for WDT
 * Nico Schottelius
 * Copying: GPL
 */

#include <string.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>
#include <stdlib.h>
#include <limits.h>

//#define PORT         1024+515
#define PORT         515
#define MY_IP        "0.0.0.0"   /* where we listen to */
#define SOCK_QUEUE   32 /* maximum elements in queue */
#define LF           0x0a  /* line feed */

/* DEBUG */
#ifdef DEBUG
# define D_PRINTF(x)  ( printf("[%s:%d]: %s\n",__FILE__,__LINE__,x) )
#else
# define D_PRINTF(x)  if(0) 
#endif


#define CONFIG_DIR   "/etc/mini-lpd"
/* #define CONFIG_DIR   "/home/user/nico/mini-lpd.test" */
#define DEVNAME      "device"
#define SLASH        "/"
#define MAX_PRINTERS 5

struct mlqueue {
   char *name;       /* name of queue */
   int   dev;        /* fd to device */
//   int   filter;   /* fd or char * to filter program */ /* not implemented */
};

/* global variables */
int sock;
struct mlqueue queues[MAX_PRINTERS];
int    qcnt;

/* whitespaces */
#define  WS_VT 0x0b  /* vertical tab */
#define  WS_HT 0x09  /* horizontal tab */
#define  WS_SP 0x20  /* space */
#define  WS_FF 0x0c  /* form feed */

char *whitespace(char *string)
{
   char *sp;

   sp = string; while(*sp != 0) { if (*sp == WS_VT) return sp; sp++; };
   sp = string; while(*sp != 0) { if (*sp == WS_HT) return sp; sp++; };
   sp = string; while(*sp != 0) { if (*sp == WS_SP) return sp; sp++; };
   sp = string; while(*sp != 0) { if (*sp == WS_FF) return sp; sp++; };

   return NULL;
}

/* we will allocate max+1 buf (\0) */
char *read_file(int socket, int bytes)
{
   char *queue = NULL, buf;
   int tmp, cnt = 0;
 
   while( (tmp = read(socket, &buf, 1)) ) {
      if(tmp == -1) {
         perror("read");
         return NULL;
      }
      cnt++;
      
      queue = realloc(queue,cnt);
      if(queue == NULL) {
         return queue;
      }
      queue[cnt-1] = buf;

      if(cnt == bytes) break;
   }
   queue = realloc(queue,cnt+1);
   if(queue == NULL) {
      return queue;
   }
   queue[cnt] = '\0'; /* add terminating \0 */
   
   return queue;
}

char *read_line(int socket, char end)
{
   char *queue = NULL, buf;
   int tmp, cnt = 0;
 
   while( (tmp = read(socket, &buf, 1)) ) {
      if(tmp == -1) {
         perror("read");
         return NULL;
      }
      cnt++;
      
      queue = realloc(queue,cnt);
      if(queue == NULL) {
         return queue;
      }
      queue[cnt-1] = buf;

      if(buf == end) { /* end of queue */
         break;
      }
   }
   if(cnt) {
      queue[cnt-1] = '\0'; /* replace LF with \0 */
   }

   return queue;
}

int print_jobs(int socket, char *queue)
{
   D_PRINTF(queue);
   free(queue);
   return 1;
} /* done */

#define  ACK   0
#define  NACK  1

int sent_ack(int socket,char code)
{
   if (write(socket,&code,1) == -1) {
     if(errno != EINVAL) {
         perror("write ack");
      }
      return 0;
   } else 
      return 1;
}

int recv_ack(int socket)
{
   char buf;

   if (read(socket,&buf,1) == -1) {
     if(errno != EINVAL) {
         perror("write ack");
      }
      return 0;
   } else {
      if(buf == 0) {
         return 1;
      } else {
         return 0;
      }
   }
}

/* recieve the job: data/control files */
int recieve_job(int socket, char *queue)
{
   char buf = NACK, *cmd = NULL, *tbuf;
   int tmp, num = 0;
   
   D_PRINTF(queue);
   while(num < qcnt) {
      if(! strcmp(queue,queues[num].name) ) {
         D_PRINTF(queues[num].name);
         buf = ACK;
         break;
      } else {
         num++;
      }
   }

   sent_ack(socket,buf);
   if(buf != ACK) return 0;

   while( (tmp = read(socket,&buf,1) ) ) {
      if(tmp == -1) {
         if(errno != EINVAL) {
            perror("rj: subcommand");
            return 0;
         }
         return 1;
      }
      
//      D_PRINTF("Subkommando:");
//      printf("SUUUUB: %c (%d)\n",buf,buf);
      
      /* read subcommand parameters, acknowledge*/
      cmd = read_line(socket,LF);
      if(cmd == NULL) {
         sent_ack(socket,NACK);
         return 0;
      }
      if( !sent_ack(socket,ACK) ) return 0;
      
//      printf("subkommando-parameter: %s\n",cmd);
      switch(buf) {
         case 1: /* abort job */
            /* read LF */
            tmp = read(socket,&buf,1);
            if(tmp == -1 || buf != LF) {
               perror("read lf");
            }
            return 0;
            break;
         case 2: /* Recieve controle file: 02 | Count | SP | Name | LF */
            cmd = read_line(socket, 0);
//            printf("controllffile: %s\n",cmd);
            
            if( !sent_ack(socket,ACK) ) return 0;

            switch(cmd[0]) {
               case 'C': /* C - Class for banner page */
               case 'H': /* H - Host name */
               case 'J': /* J - Job name for banner page */
               case 'P': /* P - User identification */
 //                 printf("%c: %s\n",cmd[0],&cmd[1]);
                  break;

               case 'I': /* I - Indent Printing */
                  break;

               case 'L': /* L - Print banner page */
                  break;

               case 'M': /* M - Mail When Printed */
                  break;

               case 'N': /* N - Name of source file */
                  break;

               case 'S': /* S - Symbolic link data */
                  break;

               case 'T': /* T - Title for pr */
                  break;

               case 'U': /* U - Unlink data file */
                  break;

               case 'W': /* W - Width of output */
                  break;

               case '1': /* 1 - troff R font */
                  break;
               /* 7.14 - 7.18 ignored */
            }
            free(cmd);
            break;
         case 3: /* Recieve data file 03 | Count | SP | Name | LF */
            tbuf = whitespace(cmd);
            if(!tbuf) return 0;

            *tbuf = 0;
            tmp = atoi(cmd);
            free(cmd);

            /* read the content of controllfile */
            cmd = read_file(socket,tmp);

            if(write(queues[num].dev,cmd,tmp) == -1) {
               perror("write data");
               return 0;
            }
            free(cmd);
            if( !recv_ack(socket) ) return 0;
            if( !sent_ack(socket,ACK) ) return 0;
            break;
      }

   }
   return 1;
}

/* we are called, if one or _more_ connections are waiting */
void sigio(int signal)
{
   int len;
   int nsock;
   struct sockaddr_in sin;
   char buf, *cmd = NULL;

   do {
      len = sizeof(struct sockaddr_in);
      nsock = accept(sock,(struct sockaddr *) &sin, &len);
   
      if( nsock == -1) {
         if (errno != EAGAIN) {
            perror("accept");
            _exit(1);
         } else {
            break;
         }
      }

      len = read(nsock,&buf,1);

      cmd = read_line(nsock, LF);

      switch(buf) {
         case 1: /* print waiting jobs */
            print_jobs(nsock,cmd);
            break;
         case 2: /* recieve a job */
            recieve_job(nsock,cmd);
            break;
         case 3: /* send queue state (short) */
            D_PRINTF("send queue state short");
            break;
         case 4: /* send queue state (long) */
            D_PRINTF("send queue state long");
            D_PRINTF(cmd);
            break;
         case 5: /* Remove Job */
            D_PRINTF("rm job");
            break;
         default:
            break;
      }
      close(nsock);

   } while ( 1 );
}

/* config: /etc/mini-lpd/
 * 
 * every queue has a directory below configdir
 * in this queue-dir is:
 * device -> link to device I should write to
 * filter -> program to pipe input to before writing to device
 */

int read_config()
{
   DIR *d_tmp = NULL;
   struct dirent *tdirent;
   char pathbuf[PATH_MAX];
   int cnt = 0;

   d_tmp = opendir(CONFIG_DIR);
   if(d_tmp == NULL) {
      return 0;
   }

   while( (tdirent = readdir(d_tmp) ) != NULL) {
      if ( *(tdirent->d_name) == '.') continue; /* skip "^\..*" */

      if(cnt == MAX_PRINTERS) break;

      queues[cnt].name = malloc( strlen(tdirent->d_name) + 1);
      if(queues[cnt].name == NULL) return 0;
      strcpy(queues[cnt].name,tdirent->d_name);

      D_PRINTF(queues[cnt].name);
      
      strcpy(pathbuf,CONFIG_DIR);
      strcat(pathbuf,SLASH);
      strcat(pathbuf,queues[cnt].name);
      strcat(pathbuf,SLASH);
      strcat(pathbuf,DEVNAME);

      queues[cnt].dev = open(pathbuf,O_RDWR|O_APPEND);

      if(queues[cnt].dev == -1) {
         perror("open printer");
         return 0;
      }
      cnt++;
   }
   qcnt = cnt;
 
   return 1;
}

int main()
{
   int tmp;
   pid_t pid;
   char ip[32] = MY_IP;
   struct sigaction sa;
   struct sockaddr_in ins;
   struct timespec ts;


   if(!read_config()) return 23;
   
   /* signalhandler for SIGIO is sigio */
   sa.sa_handler=sigio;
   sigaction(SIGIO, &sa, NULL);

   ins.sin_family = AF_INET;
   ins.sin_port   = htons(PORT);
   if( ! inet_aton(ip, &(ins.sin_addr) ) ) {
      write(2,"ip kaputt\n",10);
      _exit(1);
   }

   sock = socket(PF_INET,SOCK_STREAM,0);
   if( sock == -1 ) {
      perror("socket");
      _exit(1);
   }

   pid = getpid();
//   tmp = fcntl(sock,F_GETOWN);
//   printf("SIGIO: %d\n",tmp);
   fcntl(sock,F_SETOWN,pid);
//   tmp = fcntl(sock,F_GETOWN);
//   printf("SIGIO: %d\n",tmp);

   if ( fcntl(sock,F_SETFL,O_ASYNC|O_NONBLOCK) == -1) {
      perror("fcntl");
      _exit(1);
   }

   tmp = 1;
   // lose the pesky "Address already in use" error message
   if (setsockopt(sock,SOL_SOCKET,SO_REUSEADDR,&tmp,sizeof(tmp)) == -1) {
      perror("setsockopt");
      _exit(1);
    }

   if(bind(sock,(struct sockaddr *)&ins,sizeof(ins)) == -1) {
      perror("bind");
      _exit(1);
   }

   /* start listening */
   if(listen(sock,SOCK_QUEUE) == -1) {
      perror("listen");
      _exit(1);
   }

   /* CONTINUE -1 == error */
//   s_tmp[s_idx] = accept(sock,(struct sockaddr *)&addr,

   /* from gpm */
//   memset(&addr, 0, sizeof(addr));
   
   tmp = (sizeof(ts.tv_sec) * 8);
   ts.tv_sec = (1 << (tmp-1));
//   ts.tv_sec = (1 << ( (sizeof(ts.tv_sec)* 8) -1 )) -1;

   while(1) {
      nanosleep(&ts,NULL);
   }

   return 0;
}
