/***********************************************************************
 *
 *    2007 Nico Schottelius (nico-cinit schottelius.org)
 *
 *    part of cLinux/cinit
 *
 *    Create new queues: One for recieving, one for sending
 *
 */

#include <mqueue.h>

#include "cinit.h"
#include "config.h"
#include "msgq-rt.h"

int cinit_ipc_init(void)
{

   return 1;
}
