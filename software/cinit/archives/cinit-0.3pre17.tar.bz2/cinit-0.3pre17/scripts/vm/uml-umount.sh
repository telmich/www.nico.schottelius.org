SDIR=$(dirname $0)
DDIR=$(dirname $0)/root
sudo umount "$DDIR"
