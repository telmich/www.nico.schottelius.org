#!/bin/sh
# Nico Schottelius
# 2007-05-21
#
# Task:
#  Reads list of services to enabled from stdin
#  Services must already exist
#
# Options:
# -d: alternate destination directory (instead of /etc/cinit/svc)
