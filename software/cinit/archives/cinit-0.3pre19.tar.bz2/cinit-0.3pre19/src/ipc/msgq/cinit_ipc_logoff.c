/***********************************************************************
 *
 *    2007 Nico Schottelius (nico-cinit schottelius.org)
 *
 *    part of cLinux/cinit
 *
 *    Disconnect from cinit
 *
 */

int cinit_ipc_logoff(void)
{
   return 1;
}
