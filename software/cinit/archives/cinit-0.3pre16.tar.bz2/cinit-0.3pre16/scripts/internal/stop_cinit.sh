#!/bin/sh
# Linux specific, but don't care, I am the only person that should use it

killall -TERM cinit
