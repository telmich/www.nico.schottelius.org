/*********************************************************************************
 * 
 *       smtp_logger
 *
 *       This file is copied from cinit (see http://unix.schottelius.org/cinit/)
 *       (c) 2005 Nico Schottelius (nico-linux-cinit at schottelius.org)
 *
 *       Adapted for smtp_logger, Nico Schottelius, 2006-08-03
 *
 *       remove dead children
 */

#include <sys/wait.h>      /* waitpid  */
#include <stdio.h>         /* NULL     */

#include "smtp_logger.h"

void sig_child(int tmp)
{
   do {
      /* check if it's a watched child */
      tmp = (int) waitpid(-1, NULL, WNOHANG);
   } while(tmp > 0);
}
