/***********************************************************************
 *
 *    smtp_logger
 *
 *    Author: Nico Schottelius
 *    Date: 2006-08-03
 *
 *    Handle one connection
 */

#include <sys/types.h>     /* socket(), fork          */
#include <unistd.h>        /* read/write, fork        */
#include <stdio.h>         /* perror                  */
#include <fcntl.h>         /* fcntl, O_NONBLOK        */
#include <sys/socket.h>    /* inet_aton, socket()     */
#include <errno.h>         /* poll, errno             */
#include <netinet/in.h>    /* struct sockaddr_in      */
#include <arpa/inet.h>     /* inet_ntoa               */

#include "smtp_logger.h"

int handle_con(int sock)
{
   int                  nsock;
   char                 *remote_name;

   pid_t                pid;
   struct sockaddr_in   ins;
   socklen_t            len = sizeof(ins);

   /* return, when there are no more connections 
   if(fcntl(sock,F_SETFL,O_NONBLOCK) == -1) {
      perror("O_NONBLOCK");
      return 1;
   } */

   do { 
      nsock = accept(sock,(struct sockaddr *) &ins, &len);
      remote_name = inet_ntoa(ins.sin_addr);

      if(nsock == -1) {
         if (errno != EAGAIN && errno != EINTR) {
            perror("accept");
            return 0;
         } else {
            return 1;
         }
      }
      
      /* new socket is fine, fork and handle the next one */
      pid = fork();

      if(pid == -1) {
         perror("fork");
         return 0;
      }
      if(pid > 0) {
         close(nsock)   /* child handles it, close it for us */;
      }
      if(pid == 0) {
         close(sock);   /* child does not need to handle old socket */
         if(save_data(do_filter(nsock),remote_name)) {
            _exit(0); 
         } else {
            _exit(1); 
         }
      }
   } while(1);
   
   return 1;
}
