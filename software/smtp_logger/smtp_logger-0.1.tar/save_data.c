/***********************************************************************
 *
 *    smtp_logger
 *
 *    Author: Nico Schottelius
 *    Date: 2006-08-04
 *
 *    Save the resulting data
 */

#include <sys/stat.h>         /* stat()         */
#include <sys/time.h>         /* gettimeofday   */
#include <stdio.h>            /* NULL           */
#include <limits.h>           /* PATH_MAX       */
#include <fcntl.h>            /* open()         */
#include <string.h>           /* strncpy()      */
#include <errno.h>            /* errno...       */
#include <unistd.h>           /* getpid         */

#include "smtp_logger.h"

int save_data(char *data, char *name)
{ 
   char           buf[(sizeof(time_t)*8)+1];
   char           savepath[PATH_MAX+1];
   int            fd;
   pid_t          pid;
   struct timeval tp;

   if(gettimeofday(&tp,NULL)) { 
      return 0;
   }

   if(ultostr((unsigned int) tp.tv_sec, 10, buf, sizeof(buf))) {
      return 0;
   }

   strncpy(savepath,options.logdir,PATH_MAX);
   if(savepath[strlen(savepath)-1] != '/') {
      strncat(savepath,"/",PATH_MAX);
   }
   strncat(savepath,name,PATH_MAX);

   /* try to create directory */
   if(mkdir(savepath,0750) == -1) {
      if(errno != EEXIST) {
         perror("mkdir");
         return 0;
      }
   }

   /* add filename */
   if(savepath[strlen(savepath)-1] != '/') {
      strncat(savepath,"/",PATH_MAX);
   }
   strncat(savepath,buf,PATH_MAX);

   pid = getpid();
   if(ultostr((unsigned int) pid, 10, buf, sizeof(buf))) {
      return 0;
   }

   strncat(savepath,".",PATH_MAX);
   strncat(savepath,buf,PATH_MAX);

   if( ( fd = open(savepath,O_WRONLY | O_CREAT | O_EXCL, 0644) ) == -1) {
      perror("open logfile");
      return 0;
   }

   if(write(fd,data,strlen(data)) == -1) {
      perror("write logfile");;
      return 0;
   }

   close(fd);

   return 1;
}
