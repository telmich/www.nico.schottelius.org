/***********************************************************************
 *
 *    smtp_logger
 *
 *    Author: Nico Schottelius
 *    Date: 2006-08-04
 *
 *    Check for valid argv
 */

#include <unistd.h>        /* read/write  */
#include <string.h>        /* strlen      */
#include <sys/types.h>     /* opendir     */
#include <dirent.h>        /* opendir     */
#include <stdio.h>         /* perror      */
#include <stdlib.h>        /* atoi        */

#include "smtp_logger.h"

int do_argv(int argc, char **argv)
{ 
   DIR *logdir;

   if(argc != ARGV_COUNT) {
      if(write(2,MSG_USAGE,strlen(MSG_USAGE)) == -1) perror("write");;
      return 0;
   }
   options.logdir = *++argv;
   options.l_host = *++argv;
   options.l_port = atoi(*++argv);
   options.d_host = *++argv;
   options.d_port = atoi(*++argv);
   
   printf("Config: (%s) %s:%d, %s:%d\n",options.logdir,options.l_host,
         options.l_port, options.d_host, options.d_port);

   /* test logdir */
   logdir = opendir(options.logdir);
   if(!logdir) {
      perror(MSG_NODIR);
      return 0;
   }
   closedir(logdir);

   return 1;
}
