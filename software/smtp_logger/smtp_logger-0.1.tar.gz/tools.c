/***********************************************************************
 *
 *    This file is part of the small helper c-library (shcl)
 *
 *    Author: René Nussbaumer and Nico Schottelius
 *    Date:   2006-08-07
 *
 *
 *    Modified for use with smtp_logger by Nico Schottelius
 *
 */

#include <unistd.h>

#define EOUTOFRANGE     (1 << 1);
#define EBUFFERTOOSMALL (1 << 2);

static const char mapping[] = "0123456789abcdef";

static void reverse(char* s) {
    char *start, *end;
    char buf[2];

    start = end = s;

    while(*end++);

    end -= 2;

    while(start < end) {
        buf[0] = *start;
        buf[1] = *end;

        *start = buf[1];
        *end   = buf[0];

        end--;
        start++;
    }
}

static void convert(unsigned long value, unsigned int base, char* converted, size_t size) {
    unsigned int i = 0;

    for(i = 0; i < size; ++i)
        converted[i] = 0;

    i = 0;

    do {
        converted[i++] = mapping[value % base];
        value /= base;
    } while(value);

    reverse(converted);
}

static int boundary(unsigned int base, size_t size, int typesize) {
    if(base < 2 || base > sizeof(mapping))
        return -EOUTOFRANGE;

    if(size < (typesize * 8) + 1)
        return -EBUFFERTOOSMALL;

    return 0;
}

int ultostr(unsigned long value, unsigned int base, char* converted, size_t size) {
    int i;

    if((i = boundary(base, size, sizeof(value))))
        return i;

    convert(value, base, converted, size);

    return 0;
}
