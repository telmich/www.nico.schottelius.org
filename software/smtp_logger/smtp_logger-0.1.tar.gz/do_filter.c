/***********************************************************************
 *
 *    smtp_logger
 *
 *    Author: Nico Schottelius
 *    Date: 2006-08-03
 *
 *    This code does the 'filter' job, simply passing data from a to b
 */

#include <sys/socket.h>    /* shutdown()     */
#include <sys/select.h>    /* select()       */
#include <stdio.h>         /* perror()       */
#include <unistd.h>        /* read/write     */
#include <string.h>        /* strncpy        */
#include <ctype.h>         /* tolower        */
#include <stdlib.h>        /* *alloc         */

#include "smtp_logger.h"

/***********************************************************************
 * Read all RCTP_TOs
 */
char *do_filter(int fd_client)
{ 
   int tmp, *fd_read, *fd_write, s_tmpdata, i;
   int fd_server;
   char buf[READ_BUF], *tmpdata;
   char data[4];
   fd_set rfds;

   /* open connection to real mailserver */
   fd_server = open_forward();

   if(fd_server == -1) {
      return NULL;
   }

   tmpdata     = NULL;
   s_tmpdata   = 0;

   do {
      /* prepare select() */
      FD_ZERO(&rfds);
      FD_SET(fd_client,&rfds);
      FD_SET(fd_server,&rfds);
      tmp = 1+ ((fd_client > fd_server) ? fd_client : fd_server);
      tmp = select(tmp,&rfds,NULL,NULL,NULL);

      if(tmp == -1) {
         perror("select");
         break;
      }

      if(FD_ISSET(fd_server, &rfds)) {
         fd_read  = &fd_server;
         fd_write = &fd_client;
      } else {
         fd_read     = &fd_client;
         fd_write    = &fd_server;
      }

      while( (tmp = read(*fd_read,buf,sizeof(buf))) ) {
         if(tmp == -1) {
            perror("read");
            break;
         }

         /* log input from client, as long as there's no DATA */
         if(*fd_read == fd_client) {
            /* in data */
            if(s_tmpdata < 0) {
               if(tmp == 3) {
                  /* .<CR><LF> */
                  if(buf[0] == '.' && buf[1] == '\r' && buf[2] == '\n') {
                     s_tmpdata *= -1; /* positive */
                  }
               }
            } else {
               if(! strncpy(data,buf,sizeof(data)) ) return NULL;

                for(i=0;i<sizeof(data) && i<tmp;i++) {
                  data[i] = tolower(data[i]);
               }

               if(strncmp(data,"data",4)) {
                  s_tmpdata += tmp;

                  tmpdata = realloc(tmpdata,s_tmpdata+1);
                  if(!tmpdata) return NULL;

                  /* initial copy */
                  if(s_tmpdata == tmp) {
                     strncpy(tmpdata,buf,tmp);
                     tmpdata[tmp] = 0;
                  } else {
                     strncat(tmpdata,buf,tmp);
                  }
               } else { /* terminate string, data is in progress */
                  s_tmpdata *= -1;
               }
            }
         }

         tmp = write(*fd_write,buf,tmp);

         if(tmp == -1) {
            perror("write");
            break;
         }

         /* this message is at the end, if read read less than maximum bytes */
         if(tmp < sizeof(buf)) break;
      }
   } while(tmp > 0); /* number of bytes read, 0=eof (conn closed), -1=error */
   
   /* do we need both, shutdown and close? */
   shutdown(fd_server,SHUT_RDWR);
   close(fd_server);
   shutdown(fd_client,SHUT_RDWR);
   close(fd_client);

   return tmpdata;
}
