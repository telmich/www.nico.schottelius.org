/***********************************************************************
 *
 *    smtp_logger
 *
 *    Author: Nico Schottelius
 *    Date: 2006-08-03
 *
 *    main routine
 */

#include <sys/types.h>     /* socket(), fork       */
#include <sys/socket.h>    /* inet_aton, socket()  */
#include <arpa/inet.h>     /* inet_addr            */
#include <string.h>        /* memset               */
#include <stdio.h>         /* perror               */
#include <poll.h>          /* poll                 */
#include <errno.h>         /* poll                 */
#include <unistd.h>        /* read/write, fork     */
#include <stdlib.h>        /* malloc               */
#include <signal.h>        /* signal handler       */
#include <netdb.h>         /* gethostbyname        */
#include <fcntl.h>         /* fcntl                */
#include <netinet/in.h>    /* sockaddr_in (posix)  */


#include "smtp_logger.h"

int main(int argc, char **argv)
{
   int sockl;
   int tmp;

   struct sigaction     sa;
   struct sockaddr_in   source_addr;
   struct hostent       *he = NULL;
   struct pollfd        plist;
   
   if(!do_argv(argc,argv)) return 1;

   /* signal handling: remove childs as they die */
   sa.sa_handler = sig_child;
   sigaction(SIGCHLD,&sa,NULL);

   /* set to sane values */
   bzero((char *) &source_addr, sizeof(source_addr));
   source_addr.sin_family = AF_INET;
   source_addr.sin_port   = htons(options.l_port);
   
   /* resolv name of listening address */
   he = gethostbyname(options.l_host);
   if(!he) {
      source_addr.sin_addr.s_addr = inet_addr(options.l_host);
      if (source_addr.sin_addr.s_addr == -1) {
         if(write(2,MSG_INVIP,strlen(MSG_INVIP)) == -1) perror("write");
         return 0;
      }
   } else { /* Extract the IP address */
      bcopy(he->h_addr, (char *) &source_addr.sin_addr, he->h_length);
   }

   sockl = socket(PF_INET,SOCK_STREAM,0);
   if( sockl == -1 ) {
      perror("socket");
      return 1;
   }

   tmp = 1;
   // lose the pesky "Address already in use" error message
   if (setsockopt(sockl,SOL_SOCKET,SO_REUSEADDR,&tmp,sizeof(tmp)) == -1) {
      perror("setsockopt");
      return 1;
   }

   if(bind(sockl,(struct sockaddr *)&source_addr,sizeof(source_addr)) == -1) {
      perror("bind");
      return 1;
   }

   /* start listening */
   if(listen(sockl,SOCK_QUEUE) == -1) {
      perror("listen");
      return 1;
   }

   /* return, when there are no more connections (in subfunction, not here */
   if(fcntl(sockl,F_SETFL,O_NONBLOCK) == -1) {
      perror("O_NONBLOCK");
      return 1;
   }

   plist.fd = sockl;
   plist.events = POLLIN | POLLPRI;
   while(1) {
      if(poll(&plist, 1, -1) == -1) {
         if(errno != EINTR) {
            perror("poll");
            return 1;
         }
      }

      if((plist.revents & POLLIN) == POLLIN ||
      (plist.revents & POLLPRI) == POLLPRI) {
         handle_con(sockl);
      }
   }

   return 0;
}
