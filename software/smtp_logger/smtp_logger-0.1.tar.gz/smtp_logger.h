/***********************************************************************
 *
 *    smtp_logger
 *
 *    Author: Nico Schottelius
 *    Date: 2006-08-03
 *
 *    Main header
 */

struct prog_opts {
   char *logdir;

   char *d_host;
   int   d_port;

   char *l_host;
   int   l_port;
} options;

/***********************************************************************
 * Defines
 */
#define SOCK_QUEUE   32
#define READ_BUF     1024
#define MAX_HEADER   1024
#define ARGV_COUNT   6
#define MSG_USAGE    "smtp_logger 0.1 - written by Nico Schottelius\n\nUsage: smtp_logger <logdir> <listen_ip> <listen_port> <connect_ip> <connect_port>\n"
#define MSG_NODIR    "Cannot open logdir"
#define MSG_INVIP    "IP adress is invalid"

/***********************************************************************
 * Functions
 */

int   handle_con(int sock);
char  *do_filter(int nsock);
int   open_forward(void);
void  sig_child(int tmp);
int   do_argv(int argc, char **argv);
int   save_data(char *data, char *name);

/***********************************************************************
 * External functions
 */

int ultostr(unsigned long value, unsigned int base, char* converted, size_t size);
