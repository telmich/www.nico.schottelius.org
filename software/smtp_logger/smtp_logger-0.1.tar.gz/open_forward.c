/***********************************************************************
 *
 *    smtp_logger
 *
 *    Author: Nico Schottelius
 *    Date: 2006-04-03
 *
 *    Open channel to forward smtp query
 */

#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdio.h>
#include <strings.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>           /* strlen         */
#include <unistd.h>           /* write          */

#include "smtp_logger.h"

/*
 * Open connection to real IP
 *
 * Returns connection to use
 */
int open_forward(void)
{
   int sock;
   struct sockaddr_in dest_addr;
   struct hostent *he = NULL;

   bzero((char *) &dest_addr, sizeof(dest_addr));
   dest_addr.sin_family = AF_INET;

   he = gethostbyname(options.d_host);
   if(!he) {
      dest_addr.sin_addr.s_addr = inet_addr(options.d_host);
      if (dest_addr.sin_addr.s_addr == -1) {
         if(write(2,"Cannot find ",12) == -1) perror("write");
         if(write(2,options.d_host,strlen(options.d_host)) == -1) perror("write");;
         if(write(2,"\n",1) == -1) perror("write");;
         return -1;
      }
   } else { /* Extract the IP address */
      bcopy(he->h_addr, (char *) &dest_addr.sin_addr, he->h_length);
   }

   dest_addr.sin_port = htons(options.d_port);

   sock = socket(PF_INET,SOCK_STREAM,0);
   if(sock == -1) {
      perror("sock");
      return -1;
   }

   if( connect(sock,(struct sockaddr *) &dest_addr,sizeof(dest_addr)) == -1) {
      perror("connect");
      return -1;
   } else {
      return sock;
   }
}
